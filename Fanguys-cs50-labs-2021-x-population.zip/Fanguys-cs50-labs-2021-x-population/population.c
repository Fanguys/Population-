#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // TODO: Prompt for start size
    
    int start;
    do
    {
        start = get_int("Starting Population:");
        
    }
    while(start < 9);
    
    //TODO: Prompt for end size
    
    int end;
    do
    {
        end = get_int("Starting Population: ");
    }
    while(start>end);
    
    //TODO : calculate number of years until we reach treshold
    
    int year = 0;
    do
    {
        start = start + (start/3) - (start/4);
        year++;
    }
    while(start < end);
    
    //TODO: Print the number of years
    
    Printf("Years: %i\n", year);
    
}